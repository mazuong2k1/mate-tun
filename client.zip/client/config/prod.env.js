'use strict'
module.exports = {
  NODE_ENV: '"production"',
  devServer: {
    proxy: '"https://api.gl6.guru"'
  }
}
